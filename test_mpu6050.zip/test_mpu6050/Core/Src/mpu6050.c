/*
 * MPU6050.c
 *
 *  Created on: Dec 4, 2023
 *      Author: Ashu
 */

#include "mpu6050.h"
#include <main.h>

extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart2;

uint8_t i2cNR[] = "Device not ready!!\r\n";
uint8_t i2cR[] = "Device is ready!!\r\n";

uint8_t conGOK[] = "Configuring GYRO!!\r\n";
uint8_t NconGOK[] = "failed to Configuring GYRO!!\r\n";

uint8_t conAOK[] = "Configuring ACC!!\r\n";
uint8_t NconAOK[] = "failed to Configuring ACC!!\r\n";

uint8_t sleepOK[] = "Exiting from sleep!!\r\n";
uint8_t NsleepOK[] = "failed to exit from sleep!!\r\n";

int16_t x_acc;
int16_t y_acc;
int16_t z_acc;
int16_t x_gyro;
int16_t y_gyro;
int16_t z_gyro;
int16_t mpu_temp;

int16_t cal_mpu;
int16_t cal_xacc;


void mpu6050_init(I2C_HandleTypeDef *I2Cx)
{
	HAL_StatusTypeDef ret =  HAL_I2C_IsDeviceReady(I2Cx, DEVICE_ADDRESS, 1, 100);

		if (ret == HAL_OK)
		{
			HAL_UART_Transmit(&huart2, i2cR, sizeof (i2cR),100);
		}
		else
		{
			HAL_UART_Transmit(&huart2, i2cNR, sizeof (i2cNR),100);
		}
		HAL_Delay(500);



	uint8_t gyro_con = FS_GYRO_250;
	HAL_StatusTypeDef con_gyro = HAL_I2C_Mem_Write(I2Cx, DEVICE_ADDRESS, REG_CONFIG_GYRO, 1, &gyro_con, 1, 100);
	{
		if (con_gyro == HAL_OK)
		{
			HAL_UART_Transmit(&huart2, conGOK, sizeof (conGOK),100);
		}
		else
		{
			HAL_UART_Transmit(&huart2, NconGOK, sizeof (NconGOK),100);
		}
	}
	HAL_Delay(500);



	uint8_t accel_con = FS_ACC_2G;
	HAL_StatusTypeDef con_acc = HAL_I2C_Mem_Write(I2Cx, DEVICE_ADDRESS, REG_CONFIG_ACC, 1, &accel_con, 1, 100);
		{
			if (con_acc == HAL_OK)
			{
				HAL_UART_Transmit(&huart2, conAOK, sizeof (conAOK),100);
			}
			else
			{
				HAL_UART_Transmit(&huart2, NconAOK, sizeof (NconAOK),100);
			}
		}
		HAL_Delay(500);



	uint8_t wake = 0;
	HAL_StatusTypeDef exit_sleep = HAL_I2C_Mem_Write(I2Cx, DEVICE_ADDRESS, REG_USR_CTRL, 1, &wake, 1, 100);
			{
				if (exit_sleep == HAL_OK)
				{
					HAL_UART_Transmit(&huart2, sleepOK, sizeof (sleepOK),100);
				}
				else
				{
					HAL_UART_Transmit(&huart2, NsleepOK, sizeof (NsleepOK),100);
				}
			}
			HAL_Delay(500);

}


void MPU6050_Read_Accel(I2C_HandleTypeDef *I2Cx)
{
	char acc_data[6];

    // Read 6 BYTES of data starting from REG_ACCEL register

	HAL_I2C_Mem_Read(I2Cx, DEVICE_ADDRESS, REG_ACCEL, 1, acc_data, 6, 100);

		x_acc = (int16_t)(acc_data[0] << 8 | acc_data[1]);
		y_acc = (int16_t)(acc_data[2] << 8 | acc_data[3]);
		z_acc = (int16_t)(acc_data[4] << 8 | acc_data[5]);

    char acc_buffer[50];
    sprintf(acc_buffer, "Accel_X: %d, Accel_Y: %d, Accel_Z: %d\n", x_acc, y_acc, z_acc);
    HAL_UART_Transmit(&huart2, (uint8_t *)acc_buffer, strlen(acc_buffer), 100);
}



void MPU6050_Read_Gyro(I2C_HandleTypeDef *I2Cx)
{
	uint8_t gyro_Data[6];

	    // Read 6 BYTES of data starting from REG_GYRO register

	    HAL_I2C_Mem_Read(I2Cx, DEVICE_ADDRESS, REG_GYRO, 1, gyro_Data, 6, 100);

	    x_gyro = (int16_t)(gyro_Data[0] << 8 | gyro_Data[1]);
	    y_gyro = (int16_t)(gyro_Data[2] << 8 | gyro_Data[3]);
	    z_gyro = (int16_t)(gyro_Data[4] << 8 | gyro_Data[5]);

	    char gyro_buffer[50];
		sprintf(gyro_buffer, "Gyro_X: %d, Gyro_Y: %d, Gyro_Z: %d\n", x_gyro, y_gyro, z_gyro);
		HAL_UART_Transmit(&huart2, (uint8_t *)gyro_buffer, strlen(gyro_buffer), 100);

}


void temperaturee(I2C_HandleTypeDef *I2Cx)
{
	char tempp[20];
	HAL_StatusTypeDef retq = HAL_I2C_Mem_Read(I2Cx, DEVICE_ADDRESS, temperature, 1, tempp, 2, 100);
			{
				if (retq == HAL_OK)
				{
					mpu_temp = ((int16_t)tempp[0] << 8) + tempp[1];
					cal_mpu = mpu_temp/340 + 36.53;
					sprintf(tempp, "MPU_TEMP: %d*C\n", cal_mpu);
					HAL_UART_Transmit(&huart2, (uint8_t *)tempp, strlen(tempp), 100);
				}
			}
			HAL_Delay(500);
}



